# MOKSH MCQ TEST — Android APK project

यह Android Studio project आपकी मौजूदा `moksh_mcq_test.html` वेबसाइट को एक offline Android app में wrap करता है। ऐप HTML को फोन के अंदर से चलाता है; वेबसाइट खोलने के लिए इंटरनेट की जरूरत नहीं है।

## क्या काम करेगा
- मौजूदा HTML UI और उसमें implemented MCQ features
- WebView JavaScript और DOM storage चालू
- HTML `localStorage` के जरिए app के अंदर स्थानीय डेटा सेव होना
- App को बंद/दोबारा खोलने पर सेव डेटा सामान्यतः बना रहना
- Android back button support

## Build करने के लिए
1. Android Studio (stable) और Android SDK Platform 35 इंस्टॉल करें।
2. इस ZIP को extract करें।
3. Android Studio में **Open** चुनें और `MOKSH_MCQ_TEST_Android` फ़ोल्डर चुनें।
4. Gradle sync पूरा होने दें। अगर JDK पूछा जाए तो **Embedded JDK 17** चुनें।
5. फोन में Developer options → USB debugging चालू करें, USB से जोड़ें, फिर **Run ▶** दबाएँ; या emulator चुनें।
6. APK बनाने के लिए **Build → Build Bundle(s) / APK(s) → Build APK(s)** चुनें।
7. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा। Android Studio के Build notification में **locate** लिंक भी दिख सकता है।
8. APK को अपने फोन में भेजकर install करें। फोन में “Install unknown apps” की अनुमति मांगी जा सकती है।

## Offline storage और backup
- डेटा इस ऐप के WebView origin/storage में सेव होता है, Chrome browser के localStorage में नहीं।
- App uninstall या **Clear storage/data** करने पर स्थानीय डेटा मिट सकता है। नियमित रूप से वेबसाइट के JSON backup/export विकल्प का उपयोग करें।
- फोन की Settings में ऐप का storage clear न करें, जब तक डेटा मिटाना न चाहें।

## महत्वपूर्ण सीमाएँ
- यह project आपकी मौजूदा HTML file को wrap करता है; HTML में जो feature पहले से implement नहीं है, वह केवल APK बनाने से अपने-आप नहीं जुड़ता।
- PDF/Excel import, OCR, AI API, accounts और cloud sync तभी उपलब्ध होंगे जब वे HTML/backend में वास्तव में implement और configured हों।
- HTML file picker को Android WebView में पूरी तरह support करने के लिए `WebChromeClient.onShowFileChooser` integration की जरूरत हो सकती है। यदि Upload File button Android पर file picker न खोले, तो यह अतिरिक्त native file-picker integration जोड़ना होगा।
- इस ZIP में Android project source है; prebuilt APK नहीं। APK Android Studio में build करें।
- पहले test data डालें, app बंद करके फिर खोलें और verify करें कि डेटा बना हुआ है। फिर अपने महत्वपूर्ण डेटा का JSON backup export करें।

## सिर्फ मोबाइल से APK बनाना (GitHub Actions)
1. GitHub पर account बनाएं/लॉगिन करें: https://github.com/
2. नया **private repository** बनाएं, उदाहरण: `MOKSH-MCQ-TEST-Android`।
3. इस ZIP को फोन में extract करें। GitHub वेबसाइट पर repository खोलकर **Add file → Upload files** से project की सभी फाइलें अपलोड करें। `.github/workflows/build-apk.yml` फाइल भी अपलोड होनी चाहिए। बेहतर है ZIP को पहले फोन के file manager में extract करें, ताकि सभी project files और hidden `.github` folder दिखें।
4. अपलोड पूरा होने पर repository में **Actions** टैब खोलें। `Build MOKSH MCQ TEST APK` workflow चुनें और **Run workflow** दबाएं। पहली बार workflow दिखाई न दे तो `build-apk.yml` फाइल `main` branch में मौजूद है, यह जांचें।
5. Build पूरा होने तक प्रतीक्षा करें। हरा checkmark सफल build दर्शाता है। Run के पेज के नीचे **Artifacts** में `MOKSH-MCQ-TEST-debug-apk` डाउनलोड करें।
6. डाउनलोड ZIP को extract करें; उसमें `app-debug.apk` होगा। APK खोलकर install करें। Android पूछे तो अपने browser/file manager के लिए “Install unknown apps” की अनुमति दें।

**ध्यान दें:** GitHub की वेबसाइट पर मोबाइल से hidden `.github` folder सहित बहुत सारी फाइलें अपलोड करना थोड़ा मुश्किल हो सकता है। Repository को public करने की जरूरत नहीं है। Debug APK परीक्षण/अपने उपयोग के लिए है; इसे Play Store पर सीधे publish करने के लिए अलग release signing और Play Console setup चाहिए।
