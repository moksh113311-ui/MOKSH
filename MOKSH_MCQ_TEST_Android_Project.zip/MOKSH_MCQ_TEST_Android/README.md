# MOKSH MCQ TEST — Android APK project

यह Android Studio project आपकी मौजूदा `moksh_mcq_test.html` वेबसाइट को एक offline Android app में wrap करता है। ऐप HTML को फोन के अंदर से चलाता है; वेबसाइट खोलने के लिए इंटरनेट की जरूरत नहीं है।

## क्या काम करेगा
- मौजूदा HTML UI और उसमें implemented MCQ features
- WebView JavaScript और DOM storage चालू
- HTML `localStorage` के जरिए app के अंदर स्थानीय डेटा सेव होना
- App को बंद/दोबारा खोलने पर सेव डेटा सामान्यतः बना रहना
- Android back button support

## Build करने के लिए
1. Android Studio (stable) और Android SDK Platform 35 इंस्टॉल करें।
2. इस ZIP को extract करें।
3. Android Studio में **Open** चुनें और `MOKSH_MCQ_TEST_Android` फ़ोल्डर चुनें।
4. Gradle sync पूरा होने दें। अगर JDK पूछा जाए तो **Embedded JDK 17** चुनें।
5. फोन में Developer options → USB debugging चालू करें, USB से जोड़ें, फिर **Run ▶** दबाएँ; या emulator चुनें।
6. APK बनाने के लिए **Build → Build Bundle(s) / APK(s) → Build APK(s)** चुनें।
7. APK आम तौर पर `app/build/outputs/apk/debug/app-debug.apk` में मिलेगा। Android Studio के Build notification में **locate** लिंक भी दिख सकता है।
8. APK को अपने फोन में भेजकर install करें। फोन में “Install unknown apps” की अनुमति मांगी जा सकती है।

## Offline storage और backup
- डेटा इस ऐप के WebView origin/storage में सेव होता है, Chrome browser के localStorage में नहीं।
- App uninstall या **Clear storage/data** करने पर स्थानीय डेटा मिट सकता है। नियमित रूप से वेबसाइट के JSON backup/export विकल्प का उपयोग करें।
- फोन की Settings में ऐप का storage clear न करें, जब तक डेटा मिटाना न चाहें।

## महत्वपूर्ण सीमाएँ
- यह project आपकी मौजूदा HTML file को wrap करता है; HTML में जो feature पहले से implement नहीं है, वह केवल APK बनाने से अपने-आप नहीं जुड़ता।
- PDF/Excel import, OCR, AI API, accounts और cloud sync तभी उपलब्ध होंगे जब वे HTML/backend में वास्तव में implement और configured हों।
- Native Android file picker integration शामिल है, ताकि HTML का file input दस्तावेज़ चुन सके। फिर भी, कौन-से formats वास्तव में import होते हैं यह HTML में implemented parser पर निर्भर है।
- इस ZIP में Android project source है; prebuilt APK नहीं। APK Android Studio में build करें।
- पहले test data डालें, app बंद करके फिर खोलें और verify करें कि डेटा बना हुआ है। फिर अपने महत्वपूर्ण डेटा का JSON backup export करें।
